// Keep the local video engine; expose only the essentials in the everyday UI.
(() => {
  const original = document.createElement('div');
  original.hidden = true;
  original.id = 'original-editor';
  for (const node of [...document.body.children]) {
    if (node.tagName !== 'SCRIPT' && !node.classList.contains('modal-overlay')) original.append(node);
  }
  document.body.prepend(original);
  const shell = document.createElement('main');
  shell.className = 'simple-editor';
  shell.innerHTML = `
    <header class="simple-header">
      <a class="simple-brand" href="#" aria-label="SkimStudio home">SS<span>SkimStudio<small>A LITTLE ROUGH. A LOT EASIER.</small></span></a>
      <span class="simple-local">ON YOUR DEVICE. JUST FOR YOU.</span>
    </header>
    <div class="simple-intro"><span class="simple-kicker">LESS FUSS. MORE FOOTAGE.</span><h1>A GOOD CLIP.<br>A GREAT <em>FINISH.</em></h1><p>Add your video, pick a look, and make the cut.</p></div>
    <div class="simple-workspace">
      <section class="simple-controls" aria-label="Edit your clip">
        <section class="simple-step"><h2><span>01</span> Add your video</h2><div id="simple-upload"></div><div id="simple-clips"></div></section>
        <section class="simple-step"><h2><span>02</span> Pick a look</h2><div class="simple-presets" role="group" aria-label="Video look">
          <button data-look="none" aria-pressed="false"><i class="look-original"></i>Original<small>Keep it natural</small></button>
          <button data-look="cine" aria-pressed="true"><i class="look-cinematic"></i>Cinematic<small>A little drama</small></button>
          <button data-look="bw" aria-pressed="false"><i class="look-noir"></i>Noir<small>Black & white</small></button>
        </div></section>
        <details class="simple-extras"><summary>A few extras <span>+</span></summary><div class="simple-extra-fields">
          <label class="simple-option">Framing <select id="simple-framing"><option value="fill">Fill the screen</option><option value="fit">Keep the full video</option></select></label>
          <div class="simple-caption-import"><span>Captions <small>Optional · bring your own subtitle file</small></span><button id="simple-import" type="button">Add SRT file ↗</button></div>
          <label class="simple-option">Film grain <input type="checkbox" id="simple-grain"></label>
        </div></details>
        <section class="simple-finish"><div class="simple-export-label"><span>03 / MAKE IT YOURS</span><small>VERTICAL · 9:16</small></div><div id="simple-export"></div><p>No account. No setup. Just your finished clip.</p></section>
      </section>
      <section class="simple-preview" aria-label="Video preview"><div class="simple-preview-label"><span>YOUR PREVIEW</span><small>9:16</small></div><div id="simple-canvas"></div><div class="simple-player"><div id="simple-play"></div><span id="simple-time">00:00 / 00:00</span><span class="simple-preview-quality">720 × 1280</span></div><div id="simple-status" role="status" aria-live="polite"></div></section>
    </div>
    <footer class="simple-bottom"><span>LESS POLISH. MORE PERSONALITY.</span><span>MADE TO BE MADE.</span></footer>
  `;
  document.body.append(shell);
  const move = (id, destination) => document.getElementById(destination).append(document.getElementById(id));
  move('drop', 'simple-upload');
  move('list', 'simple-clips');
  document.getElementById('simple-canvas').append(document.querySelector('.canvas-wrap'));
  move('play', 'simple-play');
  move('exp', 'simple-export');
  move('st', 'simple-status');
  const timelineView = document.createElement('section');
  timelineView.className = 'simple-timeline';
  timelineView.hidden = true;
  timelineView.setAttribute('aria-label', 'Clip timeline');
  timelineView.innerHTML = '<div class="timeline-view-heading"><div><span class="simple-kicker">A CLOSER LOOK</span><h2>Your timeline.</h2></div><p>Click the ruler to jump to a moment.<br>Your clip and captions, all in one place.</p></div><p class="timeline-empty">Add a video in Frame 01 to see it here.</p>';
  timelineView.append(document.querySelector('.timeline-panel'));
  shell.querySelector('.simple-bottom').before(timelineView);
  const originalRenderTimeline = renderTimeline;
  renderTimeline = () => {
    originalRenderTimeline();
    const clip = clips[cur];
    timelineView.querySelector('.timeline-empty').hidden = Boolean(clip);
    if (!clip || clip.edl?.length) return;
    const duration = Number.isFinite(pv.duration) ? pv.duration : 0;
    $('tl_info').textContent = '1 clip';
    if (!duration) return;
    const block = document.createElement('button');
    block.className = 'tl-block tl-block-video';
    block.style.left = '0px';
    block.style.width = `${Math.max(16, duration * tlPixelsPerSec)}px`;
    block.textContent = clip.file.name;
    block.title = `${clip.file.name} · ${duration.toFixed(1)} seconds`;
    block.onclick = event => { event.stopPropagation(); seekToTimelineTime(0); };
    $('tl_video_lane').append(block);
  };
  pv.addEventListener('loadedmetadata', () => renderTimeline());
  window.addEventListener('message', event => {
    if (event.origin !== window.location.origin || event.source !== window.parent || event.data?.type !== 'clip-finisher-view') return;
    const timeline = event.data.view === 'timeline';
    shell.classList.toggle('timeline-view', timeline);
    timelineView.hidden = !timeline;
    if (timeline) renderTimeline();
    window.scrollTo({ top: 0 });
  });
  $('tm').value = 'cap';
  $('tm').dispatchEvent(new Event('change'));
  // Quiet defaults: no added sound effects, zooms, titles, or progress overlays.
  for (const id of ['sfx', 'zoom', 'bar', 'cap', 'vig']) $(id).checked = false;
  $('exp').textContent = 'Export video ↗';
  $('exp').disabled = true;
  $('play').textContent = 'Play';
  $('play').disabled = true;
  $('drop').firstChild.textContent = 'Drop a video here, or click to browse';
  setStatus('Your preview will appear here.');
  const empty = document.createElement('div');
  empty.className = 'simple-empty-preview';
  empty.innerHTML = '<span>+</span><strong>YOUR NEXT GREAT CLIP.</strong><small>Start with a video.</small>';
  document.querySelector('.canvas-wrap').append(empty);
  const updateClip = () => {
    const ready = clips.length > 0;
    empty.hidden = ready;
    $('exp').disabled = !ready || busy;
    $('play').disabled = !ready || busy;
    renderTimeline();
    if (ready && !busy) setStatus('Looking good. Preview it, or export when you’re ready.');
  };
  new MutationObserver(updateClip).observe($('list'), { childList: true, subtree: true });
  for (const button of shell.querySelectorAll('[data-look]')) {
    button.addEventListener('click', () => {
      $('grade').value = button.dataset.look;
      shell.querySelectorAll('[data-look]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    });
  }
  $('simple-framing').onchange = e => { $('mode').value = e.target.value; };
  $('simple-grain').onchange = e => { $('grain').checked = e.target.checked; };
  $('simple-import').onclick = () => {
    if (!clips.length) { setStatus('Add your video first, then import its subtitles.'); return; }
    $('srt').click();
  };
  $('srt').addEventListener('change', e => {
    if (e.target.files.length) $('cap').checked = true;
  });
  pv.addEventListener('play', () => { $('play').textContent = 'Pause'; });
  pv.addEventListener('pause', () => { $('play').textContent = 'Play'; });
  pv.addEventListener('timeupdate', () => {
    const time = seconds => {
      const s = Number.isFinite(seconds) ? Math.floor(seconds) : 0;
      return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
    };
    $('simple-time').textContent = `${time(pv.currentTime)} / ${time(pv.duration)}`;
  });
})();
