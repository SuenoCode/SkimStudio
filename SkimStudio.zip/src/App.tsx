import { useRef, useState } from 'react';

export default function App() {
  const [frame, setFrame] = useState(1);
  const editor = useRef<HTMLIFrameElement>(null);
  function switchFrame(next: number) {
    setFrame(next);
    editor.current?.contentWindow?.postMessage({ type: 'clip-finisher-view', view: next === 2 ? 'timeline' : 'simple' }, window.location.origin);
  }
  return (
    <div className="studio-shell">
      <nav className="frame-navigation" aria-label="Studio frames">
        <div className="frame-navigation-tabs">
          <button className={frame === 1 ? 'active' : ''} onClick={() => switchFrame(1)} aria-pressed={frame === 1}><span>01</span> SKIMSTUDIO <i /></button>
          <button className={frame === 2 ? 'active' : ''} onClick={() => switchFrame(2)} aria-pressed={frame === 2}><span>02</span> TIMELINE</button>
        </div>
        <span className="workshop-label">THE SHORT-FORM WORKSHOP / V.01</span>
      </nav>
      <iframe ref={editor} title={frame === 2 ? 'SkimStudio timeline' : 'SkimStudio video editing studio'} src="/skimstudio.html" className="studio-frame" onLoad={() => switchFrame(frame)} allow="autoplay; fullscreen" />
    </div>
  );
}
