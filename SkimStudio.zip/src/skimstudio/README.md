# SkimStudio editor engine

Imported from the user's `SkimStudio-caption-sync-fix.zip`. The original media,
caption-alignment, validation, worker, export, and project modules are retained.

`main.js` initializes the supplied `skimstudio.html`, then calls
`installSimpleEditor` with a small bridge to the engine's live session.
`simple-editor.js` moves the existing controls rather than creating a second
media store. Frame 01 exposes upload, look presets, preview, and export.
Frame 02 exposes the same preview and timeline; optional detailed controls live
under “More editing tools.”

The parent React app switches views with origin- and source-checked messages.
Both views use one iframe, so changing frames does not reload the engine.

Shared visual styles remain in `public/clip-finisher-grunge.css` and
`public/clip-finisher-simple.css`. The original stylesheet supplies structural
and dialog styles underneath these overrides.

Run `pnpm test:skimstudio` for the imported 36 caption, validation, history,
analysis, and export unit tests; `pnpm build` builds both HTML entry points.

The imported engine saves project metadata locally in IndexedDB; it does not
embed original media in saved project files. Speech recognition is opt-in and
downloads a model before running locally. MP4 export depends on browser codec
support. These constraints are unchanged from the uploaded engine.
